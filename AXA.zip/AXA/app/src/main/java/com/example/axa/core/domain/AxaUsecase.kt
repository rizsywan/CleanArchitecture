package com.example.axa.core.domain

interface AxaUsecase {
    fun getData(): List<AxaEntity>
}