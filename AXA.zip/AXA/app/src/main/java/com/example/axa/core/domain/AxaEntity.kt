package com.example.axa.core.domain

data class AxaEntity(
    val title: String
)
