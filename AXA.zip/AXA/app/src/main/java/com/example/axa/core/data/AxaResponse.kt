package com.example.axa.core.data

import com.google.gson.annotations.SerializedName

data class AxaResponse (
    val title: String
)